utils::globalVariables(c("data","fit1","ans1","ans2"))
