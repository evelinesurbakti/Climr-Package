#' Plot climr gp fit output
#'
#' @param x Output from the \code{\link{gp_fit}} function
#' @param ... Other arguments to plot (not currently implemented)
#'
#' @return Nothing: just a nice plot of temperature prediction with Gaussian Process
#'
#' @seealso \code{\link{load_clim}}, \code{\link{gp_fit}}
#'
#' @import ggplot2
#' @importFrom viridis "scale_color_viridis"
#'
#' @export
plot.climr_gp_fit <- function(x, ...) {
  # Create global variables to avoid annoying CRAN notes
  DJF = Dec = `J-D` = Jan = SON = Year = month = pred = quarter = temp = year = ans1 = x.clim_year = x.temp = NULL

  # Get the data set and turn it into a dataframe
  dat <- data.frame(x$clim_year,x$temp,x$pred_lm,x$pred_gp)

  # Finally create the plot
  ggplot(dat, aes(x.clim_year, x.temp)) +
    geom_point(aes(colour = x.temp)) +
    geom_line(aes(y = x$pred_gp, colour = x$temp)) +
    theme_bw() +
    xlab('Year') +
    ylab('Temperature anomaly') +
    theme(legend.position = 'None') +
    scale_color_viridis()
  }

